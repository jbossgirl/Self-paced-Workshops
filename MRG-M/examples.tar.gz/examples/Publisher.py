#!/usr/bin/env python

import sys
from qpid.messaging import *

broker = "localhost" 
address = "amq.topic" 
messages = [ "GOOG 616.47", "RHT 42.46", "VMW 78.25", "CSCO 23.29", "IBM 141.43" ];

connection = Connection(broker)

try:
  
  connection.connect();
  session = connection.session()

  sender = session.sender(address)

  for i in range(len(messages)):
    message = str(i + 1) + " " + messages[i]
    print "Sending message: " + message
    sender.send(Message(message))

except Exception as (m):
  print m
else:
  connection.close()
