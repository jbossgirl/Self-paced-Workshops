import javax.jms.*;
import javax.naming.*;
import java.util.Properties;

public class P2PReceiver {

	public static void main(String[] args) {

		Context			ctx = null;
		QueueConnectionFactory  factory = null;
		QueueConnection		conn = null;
		QueueSession		session = null;
		Queue			queue = null;
		QueueReceiver		receiver = null;
		TextMessage		message = null;
				
		try {


			/* START JNDI configuration */	
			Properties props = new Properties();

			props.setProperty("java.naming.factory.initial", "org.apache.qpid.jndi.PropertiesFileInitialContextFactory");
			props.setProperty("connectionfactory.host", "amqp://guest:guest@clientid/test?brokerlist='tcp://localhost:5672'");
			props.setProperty("destination.name", "direct");

			ctx = new InitialContext(props);

			factory = (QueueConnectionFactory) ctx.lookup("host");
			queue = (Queue) ctx.lookup("name");
			/* END JNDI configuration */

			/* receive messages */
			conn = factory.createQueueConnection();
			session = conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			receiver = session.createReceiver(queue);
			conn.start();

			while (true) {
				Message m = receiver.receive(1);

				if (m != null) {
					if (((TextMessage) m).getText().equals("END")) {
						break;
					} else {
						message = (TextMessage) m;
						System.out.println("Reading message: " + message.getText());
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Exception occurred: " + e.toString());
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {}
			}
		}
	}
}
