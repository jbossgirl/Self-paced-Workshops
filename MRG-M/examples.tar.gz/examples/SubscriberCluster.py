#!/usr/bin/env python

import sys
from qpid.messaging import *

broker = "localhost"
address = "amq.topic" 

connection = Connection(broker, 5671);

try:
  connection.connect()
  session = connection.session()
  receiver = session.receiver(address)

  print "To end program, press Ctrl-c"

  while True:
    try:
      message = receiver.fetch()
      print message.content
      session.acknowledge(message)
    except BaseException:
      break

except Exception as (m):
  print m
else:
  connection.close()
