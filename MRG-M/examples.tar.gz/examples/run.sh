#!/bin/bash

echo -n "Building class path..."
export CLASSPATH=$CLASSPATH":"`find "/usr/lib/qpid" -name '*.jar' | tr '\n' ":"`
export CLASSPATH=$CLASSPATH":"`find "/usr/share/java/" -name '*.jar' | tr '\n' ":"`
export PYTHONPATH="/usr/lib/python2.6/site-packages/qpid"

echo "Done."

EXAMPLE_CLASS="$1"

if [ "$EXAMPLE_CLASS" = "" ]; then
	echo "Usage:"
	echo "	run.sh <Hello|Publisher|Subscriber>"
	exit;
else

	# see if a specific kind of file was specified
	if [[ $EXAMPLE_CLASS =~ \.java$ ]]; then
		java_file="$EXAMPLE_CLASS"
		python_file=""
	elif [[ $EXAMPLE_CLASS =~ \.py$ ]]; then
		java_file=""
		python_file="$EXAMPLE_CLASS"
	else
		#specific file type not specified
		java_file=`echo "$EXAMPLE_CLASS" | sed 's/\./\//g'`".java"
		python_file=`echo "$EXAMPLE_CLASS" | sed 's/\./\//g'`".py"
	fi

	if [ -f "$java_file" ]; then

		EXAMPLE_CLASS=`echo $EXAMPLE_CLASS | sed 's/\.java$//'`

		javac -cp "$CLASSPATH" "$java_file" 2>&1
		result=$?

		if [ $result -ne 0 ]; then
			rm -rf *.class
			echo "Compiling example failed."
			exit 1;
		fi

		echo "Running example:"
		java -cp $CLASSPATH "-Dlog4j.configuration=file://$QPID_HOME/etc/log4j.xml" $EXAMPLE_CLASS 2>&1

		rm -rf *.class
	
	elif [ -f "$python_file" ]; then

		echo "Running example:"
		./$python_file 2>&1
	
	else

		echo $EXAMPLE_CLASS "is not a valid example"
		exit;

	fi
fi

